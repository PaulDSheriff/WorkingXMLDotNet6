﻿using XMLSamples;

// Create instance of view model
CreateViewModel vm = new();

// Call Sample Method
vm.CreateEmptyDocument();

// Stop console to view results
Console.ReadKey();
