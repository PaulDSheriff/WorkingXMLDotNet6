﻿using XMLSamples;

// Create instance of view model
LoadingViewModel vm = new();

// Call Sample Method
vm.LoadUsingXDocument();

// Stop console to view results
Console.ReadKey();