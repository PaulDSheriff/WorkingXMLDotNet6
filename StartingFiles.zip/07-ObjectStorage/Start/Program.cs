﻿using XMLSamples;

// Create instance of view model
SerializeViewModel vm = new();
 
// Call Sample Method
vm.SerializeProduct();

// Stop console to view results
Console.ReadKey();